<?php
// Conectar a la base de datos
$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
try {
    $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
    exit;
}

$codigoAlbum = $_GET['codigo'];

try {
    $discografia->beginTransaction();

    // 4. Borrar todas las canciones relacionadas con el álbum
    $consultaBorrarCanciones = $discografia->prepare("DELETE FROM cancion WHERE album = ?");
    $consultaBorrarCanciones->execute([$codigoAlbum]);

    // 5. Borrar el álbum
    $consultaBorrarAlbum = $discografia->prepare("DELETE FROM album WHERE codigo = ?");
    $consultaBorrarAlbum->execute([$codigoAlbum]);

    // 6. Realizar el commit para confirmar los cambios
    $discografia->commit();

    echo "Álbum y canciones borrados correctamente.";
} catch (PDOException $e) {
    // 7. En caso de error, realizar un rollback para deshacer cualquier cambio
    $discografia->rollBack();

    echo "Error al borrar el álbum y las canciones: " . $e->getMessage();
}
?>