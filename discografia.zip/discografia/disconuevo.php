<?php
// Inicializa las variables
$album = $discografica = $formato = $fechaLanzamiento = $fechaCompra = $precio = '';
$mensaje = '';

// Verifica si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Procesa el formulario y guarda el nuevo álbum en la base de datos
    $opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
    
    try {
        $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
    } catch (PDOException $e) {
        echo 'Falló la conexión: ' . $e->getMessage();
        exit; 
    }

    $album = $_POST['album'];
    $discografica = $_POST['discografica'];
    $formato = $_POST['formato'];
    $fechaLanzamiento = $_POST['fechaLanzamiento'];
    $fechaCompra = $_POST['fechaCompra'];
    $precio = $_POST['precio'];

    $consulta = $discografia->prepare("INSERT INTO album (album, discografica, formato, fechaLanzamiento, fechaCompra, precio) VALUES (?, ?, ?, ?, ?, ?)");
    if ($consulta->execute([$album, $discografica, $formato, $fechaLanzamiento, $fechaCompra, $precio])) {
        $mensaje = "Álbum guardado correctamente.";
        // Restablece las variables después de la inserción
        $album = $discografica = $formato = $fechaLanzamiento = $fechaCompra = $precio = '';
    } else {
        $mensaje = "Error al guardar el álbum.";
    }
}

// Muestra el formulario y el mensaje
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Añadir Álbum Nuevo</title>
</head>
<body>
    <h1>Añadir Álbum Nuevo</h1>
    <?php echo $mensaje; ?>
    <form action="disconuevo.php" method="post"><br>
        <label for="album">Código del Álbum:</label>
        <input type="text" id="codigo" name="codigo" value="<?php echo $codigo; ?>" required><br><br>

        <label for="album">Nombre del Álbum:</label>
        <input type="text" id="album" name="album" value="<?php echo $album; ?>" required><br><br>

        <label for="discografica">Discográfica:</label>
        <input type="text" id="discografica" name="discografica" value="<?php echo $discografica; ?>" required><br><br>

        <label for="formato">Formato:</label>
        <input type="text" id="formato" name="formato" value="<?php echo $formato; ?>" required><br><br>

        <label for="fechaLanzamiento">Fecha de Lanzamiento:</label>
        <input type="date" id="fechaLanzamiento" name="fechaLanzamiento" value="<?php echo $fechaLanzamiento; ?>" required><br><br>

        <label for="fechaCompra">Fecha de Compra:</label>
        <input type="date" id="fechaCompra" name="fechaCompra" value="<?php echo $fechaCompra; ?>" required><br><br>

        <label for="precio">Precio:</label>
        <input type="number" id="precio" name="precio" value="<?php echo $precio; ?>" required><br><br>

        <input type="submit" value="Guardar Álbum">
    </form>
</body>
</html>
