<?php
// Conectar a la base de datos
$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
try {
    $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
    exit; 
}

// Obtener el código del álbum desde la URL
if (isset($_GET['canciones'])) {
    $codigoAlbum = $_GET['canciones'];

    // Consulta para obtener información del álbum
    $consultaAlbum = $discografia->prepare("SELECT * FROM album WHERE codigo = ?");
    $consultaAlbum->execute([$codigoAlbum]);
    $album = $consultaAlbum->fetch(PDO::FETCH_ASSOC);

    // Consulta para obtener canciones del álbum
    $consultaCanciones = $discografia->prepare("SELECT * FROM cancion WHERE codigo = ?");
    $consultaCanciones->execute([$codigoAlbum]);
    $canciones = $consultaCanciones->fetchAll(PDO::FETCH_ASSOC);
} else {
    echo "Código de álbum no proporcionado en la URL.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Información del Álbum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1 {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        h2 {
            margin-top: 20px;
        }

        h3 {
            text-align: center;
        }

        p {
            font-size: 18px;
            margin: 10px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Información del Álbum</h1>
    <h2>Álbum: <?php echo $album['album']; ?></h2>
    <p>Discográfica: <?php echo $album['discografica']; ?></p>
    <p>Formato: <?php echo $album['formato']; ?></p>
    <p>Fecha de Lanzamiento: <?php echo $album['fechaLanzamiento']; ?></p>
    <p>Fecha de Compra: <?php echo $album['fechaCompra']; ?></p>
    <p>Precio: <?php echo $album['precio']; ?></p>

    <h1>Canciones del Álbum</h1>
    <table>
        <tr>
            <th>Título</th>
            <th>Posición</th>
            <th>Duración</th>
            <th>Género</th>
            <th>Código</th>
        </tr>
        <?php foreach ($canciones as $cancion) : ?>
            <tr>
                <td><?php echo $cancion['titulo']; ?></td>
                <td><?php echo $cancion['posicion']; ?></td>
                <td><?php echo $cancion['duracion']; ?></td>
                <td><?php echo $cancion['genero']; ?></td>
                <td><?php echo $cancion['codigo']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <h3> <br>
    <a href="cancionnueva.php?disco=<?php echo $codigoAlbum; ?>">Añadir Canción</a>
    </h3>
    <h3> 
    <a href="borrardisco.php?codigo=<?php echo $codigoAlbum; ?>">Borrar álbum y canciones</a>

    </h3>

</body>
</html>