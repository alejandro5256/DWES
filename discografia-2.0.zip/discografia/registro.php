<?php
$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');

try {
    $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
    $discografia->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
    exit;
}

// Variables para almacenar los valores del formulario
$nombre = '';
$usuario = '';
$password = '';
$confirmarPassword = '';

// Mensajes de error
$errores = array();

// Procesar el formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger los datos del formulario
    $nombre = $_POST['nombre'];
    $usuario = $_POST['nombreUsuario'];
    $password = $_POST['password'];
    $confirmarPassword = $_POST['confirmarPassword'];

    // Validar los campos
    if (empty($nombre) || empty($usuario) || empty($password) || empty($confirmarPassword)) {
        $errores[] = "Todos los campos son obligatorios.";
    }

    if ($password !== $confirmarPassword) {
        $errores[] = "Las contraseñas no coinciden.";
    }

    // Si no hay errores, proceder con la acción correspondiente
    if (empty($errores)) {
        // Generar el hash de la contraseña
        $hash = password_hash($password, PASSWORD_DEFAULT);

        // Verificar qué acción se realizó
        if (isset($_POST['accion'])) {
            if ($_POST['accion'] === 'Registrarse') {
                // Insertar el nuevo usuario en la base de datos
                $consulta = $discografia->prepare("INSERT INTO tabla_usuarios (usuario, password) VALUES (?, ?)");
                try {
                    $consulta->execute([$usuario, $hash]);
                    echo "Usuario registrado correctamente.";
                } catch (PDOException $ex) {
                    echo "Error al registrar el usuario. Puede que el nombre de usuario ya esté en uso.";
                }
            } elseif ($_POST['accion'] === 'IniciarSesion') {
                // Eliminar espacios en blanco al principio y al final del nombre de usuario
                $usuario = trim($usuario);

                // Verificar si el usuario existe en la base de datos
                $consulta = $discografia->prepare("SELECT usuario, password FROM tabla_usuarios WHERE usuario = ?");
                $consulta->execute([$usuario]);
                $usuarioEncontrado = $consulta->fetch();

                if ($usuarioEncontrado && password_verify($password, $usuarioEncontrado['password'])) {
                    echo "Inicio de sesión exitoso.";
                    // Redirigir a la página principal u otra página después del inicio de sesión
                    header("Location: index.php");
                    exit();
                } else {
                    echo "Error al iniciar sesión. Verifica tus credenciales.";
                }
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
</head>
<body>
    <h2>Registro de Usuario</h2>
    <form action="" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required><br>

        <label for="nombreUsuario">Nombre de Usuario:</label>
        <input type="text" name="nombreUsuario" id="nombreUsuario" value="<?php echo htmlspecialchars($usuario); ?>" required><br><br>

        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" required><br>

        <label for="confirmarPassword">Repetir Contraseña:</label>
        <input type="password" name="confirmarPassword" id="confirmarPassword" required><br><br>

        &nbsp;<input type="submit" name="accion" value="Registrarse">&nbsp;&nbsp;
        <a href="login.usuarios.php"><input type="button" value="Iniciar Sesión"></a>
        <!-- &nbsp;<a class="boton" href="login.usuarios.php">Iniciar Sesion</a> -->
        
    </form>
<?php
    // Mostrar mensajes de error, si los hay
    if (!empty($errores)) {
        echo '<ul>';
        foreach ($errores as $error) {
            echo '<li>' . $error . '</li>';
        }
        echo '</ul>';
    }
    ?>
   
</body>
</html>

