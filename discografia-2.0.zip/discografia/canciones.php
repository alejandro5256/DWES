<?php
    include("cerrarSesion.inc.php")

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Buscar Canciones</title>
</head>
<body>
    <h1>Buscar Canciones</h1>

    <!-- Formulario de búsqueda de canciones -->
    <form method="post" action="canciones.php">
        <label for="textoBusqueda">Texto a buscar:</label>
        <input type="text" id="textoBusqueda" name="textoBusqueda" required><br><br>

        <label for="buscarEn">Buscar en:</label>
        <select id="buscarEn" name="buscarEn"><br>
            <option value="titulos">Títulos de Canción</option>
            <option value="albumes">Nombres de Álbum</option>
            <option value="ambos">Ambos campos</option>
        </select>
        <br><br>
        <label for="generoMusical">Filtrar por Género Musical:</label>
        <select id="generoMusical" name="generoMusical">
            <!-- Aquí puedes cargar dinámicamente los géneros desde tu base de datos -->
            <option value="genero1">Clásica</option>
            <option value="genero2">BSO</option>
            <option value="genero3">Blues</option>
            <option value="genero4">Electrónica</option>
            <option value="genero5">Jazz</option>
            <option value="genero6">Metal</option>
            <option value="genero7">Pop</option>
            <option value="genero8">Rock</option>
            
            <!-- Agrega más opciones según tus géneros disponibles -->
        </select>
        <br><br>    
        <button type="submit">Buscar</button>
    </form>
</body>
</html>

<?php
// Conexión a la base de datos (reemplaza con tus credenciales)
$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
try {
    $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
    exit; 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $textoBusqueda = $_POST['textoBusqueda'];
    $buscarEn = $_POST['buscarEn'];
    $generoMusical = $_POST['generoMusical'];

    // Construye la consulta SQL según los criterios seleccionados
    $consultaSQL = "SELECT * FROM cancion WHERE ";

    if ($buscarEn === 'titulos') {
        $consultaSQL .= "titulo LIKE :textoBusqueda";
    } elseif ($buscarEn === 'albumes') {
        $consultaSQL .= "album LIKE :textoBusqueda";
    } else {
        $consultaSQL .= "(titulo LIKE :textoBusqueda OR album LIKE :textoBusqueda)";
    }

    if ($generoMusical !== 'todos') {
        $consultaSQL .= " AND genero = :generoMusical";
    }

    $consulta = $discografia->prepare($consultaSQL);
    
    $consulta->execute([
        'textoBusqueda' => "%$textoBusqueda%",
        'generoMusical' => $generoMusical,
    ]);

    // Obtiene las canciones encontradas
    $cancionesEncontradas = $consulta->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!-- HTML para mostrar los resultados (canciones encontradas) -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Resultados de la Búsqueda</title>
</head>
<body>
    <h1>Resultados de la Búsqueda</h1>

    <!-- Mostrar los resultados de la búsqueda en una tabla -->
    <?php if (isset($cancionesEncontradas) && !empty($cancionesEncontradas)): ?>
        <table>
            <tr>
                <th>Título</th>
                <th>Álbum</th>
                <th>Posición</th>
                <th>Duración</th>
                <th>Género</th>
            </tr>
            <?php foreach ($cancionesEncontradas as $cancion): ?>
                <tr>
                    <td><?php echo $cancion['titulo']; ?></td>
                    <td><?php echo $cancion['album']; ?></td>
                    <td><?php echo $cancion['posicion']; ?></td>
                    <td><?php echo $cancion['duracion']; ?></td>
                    <td><?php echo $cancion['genero']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No se encontraron canciones que coincidan con la búsqueda.</p>
    <?php endif; ?>
</body>
</html>
