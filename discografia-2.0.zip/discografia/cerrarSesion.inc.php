<?php
    setcookie('usuario', '', time() - 3600, '/');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cerrar Sesión</title>
    <style>
        /* Estilos para el botón */
        .boton {
            display: inline-block;
           align-items: center;
            background-color: green; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border: none; 
            cursor: pointer;
            border-radius: 4px; 
        }

        h2{
        text-align: center;
        }
    </style>
</head>
<body>
    
    <a class="boton" href="login.usuarios.php">Cerrar Sesion</a>
    
</body>
</html>