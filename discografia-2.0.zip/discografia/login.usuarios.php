<?php
$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
try {
    $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
    exit;
}

// Verificar si existe una cookie válida
if (isset($_COOKIE['usuario'])) {
    $nombreUsuario = $_COOKIE['usuario'];
    echo "¿Desea acceder como $nombreUsuario?<br> <br>";
    echo '<form action="" method="post">
            <input type="submit" name="confirmar" value="Sí">
            <input type="submit" name="cancelar" value="No">
          </form>';
} else {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $errores = array(); // Inicializar la matriz de errores

        // Recoger los datos del formulario
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];

        if (empty($usuario) || empty($password)) {
            $errores[] = "Todos los campos son obligatorios.";
        } else {
            // Consulta para verificar si el usuario y contraseña existen en la base de datos
            $consulta = $discografia->prepare("SELECT usuario, password FROM tabla_usuarios WHERE usuario = ? LIMIT 1");
            $consulta->execute([$usuario]);
            $usuarioEncontrado = $consulta->fetch();

            if ($usuarioEncontrado && password_verify($password, $usuarioEncontrado['password'])) {
                setcookie('usuario', $usuario, time() + 3600, '/');

                header("Location: index.php");
                exit();
            } else {
                echo "Error al realizar el login";
            }
        }
    }

    if (!isset($_COOKIE['usuario'])) {
        // Si no hay una cookie válida, mostrar el formulario de inicio de sesión
        echo '<form action="" method="post">
                <h3>Inicie sesión con un usuario:</h3>
                Usuario: <input type="text" name="usuario" id="usuario" required><br>
                Password: <input type="password" name="password" id="password" required><br>
                <input type="submit" value="Enviar">
              </form>';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirmar'])) {
        echo "Acceso correcto.";
        
    } elseif (isset($_POST['cancelar'])) {
        // Eliminar la cookie
        setcookie('usuario', '', time() - 3600, '/');
        echo "Cookie eliminada. Por favor, inicie sesión nuevamente.";
    }
}
?>