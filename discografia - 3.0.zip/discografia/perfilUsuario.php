<?php

class PerfilUsuario {
    private $nombreUsuario;
    private $rutaImagenPerfilGrande;
    public function __construct($nombreUsuario, $rutaImagenPerfilGrande) {
        $this->nombreUsuario = $nombreUsuario;
        $this->rutaImagenPerfilGrande = $rutaImagenPerfilGrande;
    }

    public function mostrarPerfil() {
        echo "<div style='display: flex; flex-direction: column; align-items: center;'>";
        echo "<h2>Nombre de Usuario</h2>";
        echo "<h3>$this->nombreUsuario</h3>";
        if (!empty($this->rutaImagenPerfilGrande) && file_exists($this->rutaImagenPerfilGrande)) {
            // Mostrar la imagen de perfil
            echo "<img src='" . htmlspecialchars($this->rutaImagenPerfilGrande) . "' alt='Imagen de Perfil'>";
        } else {
            // Mostrar un mensaje si no hay imagen
            echo "Imagen de Perfil: No disponible";
        }
        echo "<br><br>";
         echo "<br><a href='index.php'><button>Continuar</button></a>";
        echo "<br><a href='login.usuarios.php'><button>Volver Atrás</button></a>";
        echo "</div>";
    }
}

?>