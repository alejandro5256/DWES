<?php
require_once 'conexion.php';

// Crear una instancia de la clase Conexion
$conexionInstancia = new Conexion();

// Obtener la conexión PDO
$discografia = $conexionInstancia->obtenerConexion();

// Variables para almacenar los valores del formulario
$nombre = '';
$usuario = '';
$password = '';
$confirmarPassword = '';

// Mensajes de error
$errores = array();

// Procesar el formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger los datos del formulario
    $nombre = $_POST['nombre'];
    $usuario = $_POST['nombreUsuario'];
    $password = $_POST['password'];
    $confirmarPassword = $_POST['confirmarPassword'];

    // Validar los campos
    if (empty($nombre) || empty($usuario) || empty($password) || empty($confirmarPassword)) {
        $errores[] = "Todos los campos son obligatorios.";
    }

    if ($password !== $confirmarPassword) {
        $errores[] = "Las contraseñas no coinciden.";
    }

    // Si no hay errores, proceder con la acción correspondiente
    if (empty($errores)) {
        // Verificar qué acción se realizó
        if (isset($_POST['accion'])) {
            if ($_POST['accion'] === 'Registrarse') {
                // Verificar si el usuario ya existe en la base de datos
                $consultaUsuarioExistente = $discografia->prepare("SELECT COUNT(*) FROM tabla_usuarios WHERE usuario = ?");
                $consultaUsuarioExistente->execute([$usuario]);
                $usuarioExistente = $consultaUsuarioExistente->fetchColumn();

                if ($usuarioExistente > 0) {
                    $errores[] = "El nombre de usuario ya está en uso.";
                } else {
                    // Generar el hash de la contraseña
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    // Guardar las rutas de las imágenes
                    $rutaImagenPerfilGrande = '';
                    $rutaImagenPerfilPequena = '';

                    // Procesar la imagen de perfil si se proporcionó
                    if (!empty($_FILES['imagenPerfil']['name'])) {
                        $nombreArchivo = $_FILES[''][''];
                        $rutaTemporal = $_FILES[''][''];
                        $rutaDestino = '../img/usuarios/' . $usuario;

                        // Verificar el tipo de imagen
                        $tipoImagen = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
                        if ($tipoImagen != 'jpg' && $tipoImagen != 'png') {
                            $errores[] = "La imagen debe ser de tipo JPG o PNG.";
                        }

                        // Verificar el tamaño de la imagen
                        list($ancho, $alto) = getimagesize($rutaTemporal);
                        if ($ancho > 360 || $alto > 480) {
                            $errores[] = "La imagen debe tener un tamaño máximo de 360x480 pixels.";
                        }

                        // Crear el directorio si no existe
                        // if (!file_exists($rutaDestino)) {
                        //     mkdir($rutaDestino, 0777, true);
                        // }

                        // Mover el archivo temporal a la ubicación deseada
                        move_uploaded_file($rutaTemporal, $rutaDestino . $nombreArchivo);

                        // Guardar la ruta del archivo en la base de datos
                        $rutaImagenPerfilGrande = $rutaDestino . $nombreArchivo;

                        // Crear versión pequeña de la imagen
                        $rutaImagenPerfilPequena = $rutaDestino . 'thumbnail_' . $nombreArchivo;
                        $imagen = imagecreatefromjpeg($rutaImagenPerfilGrande); // Cambia a imagecreatefrompng si la imagen es PNG
                        $imagenPequena = imagescale($imagen, 72, 96);
                        imagejpeg($imagenPequena, $rutaImagenPerfilPequena);
                        imagedestroy($imagen);
                        imagedestroy($imagenPequena);
                    }

                    // Insertar el nuevo usuario en la base de datos
                    $consultaInsertarUsuario = $discografia->prepare("INSERT INTO tabla_usuarios (usuario, password, ruta_imagen_perfil_pequena, ruta_imagen_perfil_grande) VALUES (?, ?, ?, ?)");

                    try {
                        $consultaInsertarUsuario->execute([$usuario, $hash, $rutaImagenPerfilPequena, $rutaImagenPerfilGrande]);
                        echo "Usuario registrado correctamente.";
                    } catch (PDOException $ex) {
                        echo "Error al registrar el usuario. Inténtalo de nuevo.";
                    }
                }
             } 
            // elseif ($_POST['accion'] === 'IniciarSesion') {
            //     // ... Resto del código para iniciar sesión ...
            // }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
</head>

<body>
    <h2>Registro de Usuario</h2>
    <form action="" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required><br>

        <label for="nombreUsuario">Nombre de Usuario:</label>
        <input type="text" name="nombreUsuario" id="nombreUsuario" value="<?php echo htmlspecialchars($usuario); ?>" required><br><br>

        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" required><br>

        <label for="confirmarPassword">Repetir Contraseña:</label>
        <input type="password" name="confirmarPassword" id="confirmarPassword" required><br><br>

        <label for="imagenPerfil">Imagen de Perfil:</label>
        <input type="file" name="imagenPerfil" id="imagenPerfil" required><br><br>


        &nbsp;<input type="submit" name="accion" value="Registrarse">&nbsp;&nbsp;
        <a href="login.usuarios.php"><input type="button" value="Iniciar Sesión"></a>
        <!-- &nbsp;<a class="boton" href="login.usuarios.php">Iniciar Sesion</a> -->

    </form>
    <?php
    // Mostrar mensajes de error, si los hay
    if (!empty($errores)) {
        echo '<ul>';
        foreach ($errores as $error) {
            echo '<li>' . $error . '</li>';
        }
        echo '</ul>';
    }
    ?>

</body>

</html>