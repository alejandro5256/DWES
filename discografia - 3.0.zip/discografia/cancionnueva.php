<?php
    include("cerrarSesion.inc.php")

?>
<?php

// Conectar a la base de datos
$opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
try {
    $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger los datos del formulario
    $codigo = $_POST['codigo'];
    $titulo = $_POST['titulo'];
    $posicion = $_POST['posicion'];
    $duracion = $_POST['duracion'];
    $genero = $_POST['genero'];
    $codigo = $_POST['codigo'];

    // Insertar la nueva canción en la base de datos
    $consulta = $discografia->prepare("INSERT INTO cancion (titulo, album, posicion, duracion, genero, codigo) VALUES (?, ?, ?, ?, ?, ?)");
    if ($consulta->execute([$titulo, $codigo, $posicion, $duracion, $genero, $codigo])) {
        echo "Canción guardada correctamente.";
    } else {
        echo "Error al guardar la canción.";
    }
}

$codigo = $_GET['codigo'];
$consultaAlbum = $discografia->prepare("SELECT album FROM album WHERE codigo = ?");
$consultaAlbum->execute([$codigo]);
$album = $consultaAlbum->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Añadir Nueva Canción a
        <?php echo $album['album']; ?>
    </title>
</head>

<body>
    <h1>Añadir Nueva Canción a <?php echo $album['album']; ?></h1>
    <form method="POST" action="">
        <input type="hidden" name="codigo" value="<?php echo $_GET['codigo']; ?>">
        <label>Título:</label>
        <input type="text" name="titulo" required><br>

        <label>Posición:</label>
        <input type="number" name="posicion" required><br>

        <label>Duración:</label>
        <input type="text" name="duracion" required><br>

        <label>Género:</label>
        <input type="text" name="genero" required><br>

        <label>Código:</label>
        <input type="text" name="codigo" required><br>

        <input type="submit" value="Guardar Canción">
    </form>
</body>

</html>