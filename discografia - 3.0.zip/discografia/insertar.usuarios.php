
<?php  
    try {
        $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
    } catch (PDOException $e) {
        echo 'Falló la conexión: ' . $e->getMessage();
        exit; 
    }

$usuario = 'alex';
$password = '1234';
$hash = password_hash($password, PASSWORD_DEFAULT);
echo $hash;

    // Insertar la nueva canción en la base de datos
    $consulta = $discografia->prepare("INSERT INTO tabla_usuarios (usuario,password) VALUES ( ?, ?)");
    if ($consulta->execute([$usuario, $hash])) {
        echo "Usuario guardado correctamente";
    } else {
        echo "Error al guardar el usuario.";
    }


?>