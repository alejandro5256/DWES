<?php
// Incluir la clase de conexión
require_once 'conexion.php';

// Crear una instancia de la clase Conexion
$conexionInstancia = new Conexion();

// Obtener la conexión PDO
$discografia = $conexionInstancia->obtenerConexion();

// Verificar si existe una cookie válida
if (isset($_COOKIE['usuario'])) {
    $nombreUsuario = $_COOKIE['usuario'];
    echo "¿Desea acceder como $nombreUsuario?<br> <br>";
    echo '<form action="" method="post">
            <input type="submit" name="confirmar" value="Sí">
            <input type="submit" name="cancelar" value="No">
          </form>';
} else {
    // Verificar si se enviaron datos de inicio de sesión
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $errores = array(); // Inicializar la matriz de errores

        // Recoger los datos del formulario
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];

        if (empty($usuario) || empty($password)) {
            $errores[] = "Todos los campos son obligatorios.";
        } else {
            // Consulta para verificar si el usuario y contraseña existen en la base de datos
            $consulta = $discografia->prepare("SELECT usuario, password, ruta_imagen_perfil_grande FROM tabla_usuarios WHERE usuario = ? LIMIT 1");
            $consulta->execute([$usuario]);
            $usuarioEncontrado = $consulta->fetch();

            if ($usuarioEncontrado && password_verify($password, $usuarioEncontrado['password'])) {
                // Crear una instancia de la clase PerfilUsuario
                require_once 'perfilUsuario.php'; // Asegúrate de que este archivo contenga la clase PerfilUsuario

                $perfilUsuario = new PerfilUsuario($usuario, $usuarioEncontrado['password'], $usuarioEncontrado['ruta_imagen_perfil_grande']);

                // Mostrar el perfil del usuario
                $perfilUsuario->mostrarPerfil();
                exit();
            } else {
                $errores[] = "Error al iniciar sesión. Verifica tus credenciales.";
            }
        }
    }

    if (!isset($_COOKIE['usuario']) || !empty($errores)) {
        // Si no hay una cookie válida o hay errores, mostrar el formulario de inicio de sesión
        echo '<form action="" method="post">
                <h3>Inicie sesión con un usuario:</h3>
                Usuario: <input type="text" name="usuario" id="usuario" required><br>
                Password: <input type="password" name="password" id="password" required><br>
                <input type="submit" value="Enviar">
              </form>';
    }
}
?>
