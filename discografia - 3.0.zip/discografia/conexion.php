<?php

class Conexion {
    private $conexion;
    private $db;
    private $user;
    private $password;

    public function __construct(){
        $this->db = 'mysql:host=localhost;dbname=discografia;charset=utf8mb4';
        $this->user = 'discografia';
        $this->password = 'discografia';
        
        $opc = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];
        
        try {
            $this->conexion = new PDO($this->db, $this->user, $this->password, $opc);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function obtenerConexion() {
        return $this->conexion;
    }
}

?>

