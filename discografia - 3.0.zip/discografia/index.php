<?php
    include("cerrarSesion.inc.php")

?>

<?php

verAlbumes(); // Llamamos a la función verAlbumes

function verAlbumes() {
    $opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
    try {
        $discografia = new PDO('mysql:host=localhost;dbname=discografia', 'discografia', 'discografia', $opc);
    } catch (PDOException $e) {
        echo 'Falló la conexión: ' . $e->getMessage();
        return; 
    }
    
    if (!$discografia) {
        echo "Error de conexión.";
        return;
    }
    
    $resultado = $discografia->query("SELECT codigo, album, discografica, formato, fechaLanzamiento, fechaCompra, precio FROM album");
    
    if (!$resultado) {
        echo "Error al realizar la sentencia SQL";
    } else {
        if ($resultado->rowCount() == 0) { 
            echo "<p>No existe ningún álbum almacenado en la base de datos</p>";
        } else {
            // Inicia la tabla
            echo '
            <style>
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 20px auto;
                }
                th, td {
                    text-align: center;
                    padding: 5px;
                }
                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                th {
                    background-color: #04AA6D;
                    color: white;
                }
            </style>
            <table>
                <tr>
                    <th>codigo</th>
                    <th>album</th>
                    <th>discografica</th>
                    <th>formato</th>
                    <th>fechaLanzamiento</th>
                    <th>fechaCompra</th>
                    <th>precio</th>
                </tr>'
                ;
            
            while ($fila = $resultado->fetch(PDO::FETCH_ASSOC)) { // Debes usar PDO::FETCH_ASSOC para obtener un arreglo asociativo.
                echo '<tr>
                        <td><a class="ver-albumes" href="discos.php?canciones=' . $fila['codigo'] . '">' . $fila['codigo'] . '</a></td>
                        <td>' . $fila['album'] . '</td>
                        <td>' . $fila['discografica'] . '</td>
                        <td>' . $fila['formato'] . '</td>
                        <td>' . $fila['fechaLanzamiento'] . '</td>
                        <td>' . $fila['fechaCompra'] . '</td>
                        <td>' . $fila['precio'] . '</td>
                    </tr>';

            }
            
            echo '</table>'; // Cierra la tabla
            
        }
    }
 }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        /* Estilos para el botón */
        .boton {
            display: inline-block;
            background-color: #4CAF50; /* Color de fondo del botón */
            color: white; /* Color del texto del botón */
            padding: 10px 20px; /* Relleno interno del botón */
            text-decoration: none; /* Quita el subrayado del enlace */
            border: none; /* Quita el borde del botón */
            cursor: pointer;
            border-radius: 4px; /* Bordes redondeados */
        }

        h2{
        text-align: center;
        }
    </style>
</head>
<body>
    <h2> <br>
    <a class="boton" href="disconuevo.php">Agregar Disco Nuevo </a><br><br>
    <a class="boton" href="canciones.php">Buscar Canciones</a><br><br>
    <a class="boton" href="borrardisco.php">Borrar album</a>
    </h2>
</body>
</html>
